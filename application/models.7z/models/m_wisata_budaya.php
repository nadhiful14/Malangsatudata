<?php 
class m_wisata_budaya extends CI_Model
{

	public function tampil_wisata_budaya($kecamatan){
		$kcmtn=$kecamatan;
		if($kcmtn=='0000'){
			$hasil=$this->db->query("SELECT * FROM wisata_budaya WHERE status='0' ");
		}else{
			$hasil=$this->db->query("SELECT * FROM wisata_budaya WHERE status='0' AND kecamatan='$kcmtn'");
		}
		return $hasil;
	}

	public function tampil_kecamatan(){
		$hasil=$this->db->query("SELECT * FROM master_kecamatan");
		return $hasil;
	}

	public function tampil_kec(){
		$hasil=$this->db->query("SELECT * FROM wisata_budaya where status=0  GROUP BY kecamatan");
		return $hasil;
	}

	public function tampil_master_warisan(){
		$hasil=$this->db->query("SELECT * FROM master_warisan_budaya");
		return $hasil;
	}

	public function simpan_wibu($nama, $kecamatan, $desa, $fasilitas, $deskripsi, $pengelola, $publikasi, $aksesibilitas, $penginput, $jenis_warisan){
		$hasil=$this->db->query("INSERT INTO wisata_budaya
			(id, nama, kecamatan, desa, fasilitas, deskripsi, pengelola, publikasi, aksesibilitas, penginput, jenis_warisan) 
			VALUES 
			('', '$nama', '$kecamatan', '$desa', '$fasilitas', '$deskripsi', '$pengelola', '$publikasi', '$aksesibilitas', '$penginput', '$jenis_warisan')");
		return $hasil;
	}

	function ubah_wibu($id, $nama, $kecamatan, $desa, $fasilitas, $deskripsi, $pengelola, $publikasi, $aksesibilitas,  $penginput, $jenis_warisan){
		$hasil=$this->db->query("UPDATE wisata_budaya 
			SET nama='$nama', kecamatan='$kecamatan', desa='$desa', fasilitas='$fasilitas', deskripsi='$deskripsi', pengelola='$pengelola', publikasi='$publikasi', aksesibilitas='$aksesibilitas', penginput='$penginput', jenis_warisan='$jenis_warisan' where id='$id'");
		return $hasil;
	}

	function hapus_wibu($id){
		$status=1;
		$hasil=$this->db->query("UPDATE wisata_budaya SET status='$status' where id='$id'");
		return $hasil;
	}





	
	
}
?>