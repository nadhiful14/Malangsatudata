<?php 
class m_potensi_unggulan extends CI_Model
{

	public function tampil_potensi_unggulan(){
		$hasil=$this->db->query("SELECT * FROM potensi_unggulan WHERE status='0' ORDER BY kecamatan ASC");
		return $hasil;
	}

public function tampil_kecamatan(){
		$hasil=$this->db->query("SELECT * FROM master_kecamatan");
		return $hasil;
	}

	public function simpan_potensi($kecamatan, $desa, $kelembagaan, $potensi_unggulan, $keterangan, $penginput){
		$hasil=$this->db->query("INSERT INTO potensi_unggulan 
			(id, kecamatan, desa, kelembagaan, potensi_unggulan, keterangan, penginput) 
			VALUES 
			('', '$kecamatan', '$desa', '$kelembagaan', '$potensi_unggulan', '$keterangan', '$penginput')");
		return $hasil;
	} 

	function hapus_potensi_unggulan($no){
		$status=1;
		$hasil=$this->db->query("UPDATE potensi_unggulan SET status='$status' where id='$no'");
		return $hasil;
	}

	function ubah_potensi_unggulan($no, $kecamatan, $desa, $kelembagaan, $potensi_unggulan, $keterangan, $penginput){
		$hasil=$this->db->query("UPDATE potensi_unggulan SET kecamatan='$kecamatan', desa='$desa', kelembagaan='$kelembagaan', potensi_unggulan='$potensi_unggulan', keterangan='$keterangan', penginput='$penginput' where id='$no'");
		return $hasil;
	}
	
}
?>